# mypackage
This library was created as an example on how to publish your own Python package

## build this package locally
'python setup.py sdist'

## installing this package from GitHub
'pip install git +https://github.com/KgasagoGH/myPackage.git'

## updating this package from GitHub
'pip install --upgrade git +https://github.com/KgasagoGH/myPackage.git'

